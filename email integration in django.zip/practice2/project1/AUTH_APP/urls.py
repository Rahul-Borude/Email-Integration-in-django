from django.urls import path
from . import views

urlpatterns = [
    path('rv/',views.registerView, name='registerurl' ),
    path('lv/', views.loginView, name='loginurl'),
    path('lov/', views.logoutView, name='logouturl'),
    path('verify/',views.twostepView, name="verify")
]