from django.db import models

# Create your models here.
class Laptop(models.Model):
    id = models.IntegerField(primary_key=True)
    brand_name = models.CharField(max_length= 50)
    model_name =  models.CharField(max_length= 50)
    price = models.FloatField()
    rom = models.IntegerField()
    ram = models.IntegerField()
    SSD = models.IntegerField()
    HDD = models.IntegerField()
    Weight = models.FloatField()
    year = models.DateField()

    def __str__(self):
        return self.brand_name