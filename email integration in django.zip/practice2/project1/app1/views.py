from django.shortcuts import render, redirect
from .forms import LaptopForm, Laptop
from django.contrib.auth.decorators import login_required
# Create your views here.

@login_required
def laptopView(request):
    form = LaptopForm()
    template_name = 'app1/laptopform.html'
    if request.method == 'POST':
        form = LaptopForm(request.POST)
        if form.is_valid():
            form.save()
    context = {'form':form}
    return render(request, template_name, context)
    
@login_required
def showlaptop(request):
    var = Laptop.objects.all()
    template_name = 'app1/showlaptop.html'
    context = {'laptop':var}
    return render(request, template_name, context)

def updateview(request,id):
    obj = Laptop.objects.get(id=id)
    form = LaptopForm(instance=obj)
    template_name = 'app1/laptopform.html'
    if request.method == 'POST':
        form = LaptopForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            return redirect('laptopformurl')
    context = {'form':form}
    return render(request, template_name, context)

def deleteview(request, id):
    obj = Laptop.objects.get(id=id)
    template_name = 'app1/confirmation.html'
    context = {'data':obj}
    if request.method == 'POST':
        obj.delete()
        return redirect ('laptopformurl')
    return render(request, template_name, context)


