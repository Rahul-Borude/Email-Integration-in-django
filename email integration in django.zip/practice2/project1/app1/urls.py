from django.urls import path
from . import views

urlpatterns = [
    path('lv/', views.laptopView, name='laptopformurl'),
    path('sl/',views.showlaptop, name='showlaptopurl'),
    path('up/<int:id>/', views.updateview, name='updateurl'),
    path('dv/<int:id>/',views.deleteview, name='deleteurl')
]